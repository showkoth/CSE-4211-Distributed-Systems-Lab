
public class CourseNotExistsException extends Exception
{
    public CourseNotExistsException(String s)
    {
        super(s);
    }
}