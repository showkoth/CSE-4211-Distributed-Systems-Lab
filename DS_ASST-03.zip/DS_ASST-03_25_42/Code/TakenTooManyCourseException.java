
public class TakenTooManyCourseException extends Exception
{
    public TakenTooManyCourseException(String s)
    {
        super(s);
    }
}