import java.io.IOException;
import java.rmi.RemoteException;
import java.util.List;

public interface Client_i extends java.rmi.Remote {

    public List<String> GetRegistrationList(String studentID)
            throws IOException, java.rmi.RemoteException, StudentNotExistsException;

    public boolean Register(String studentID, String courseID)
            throws IOException, java.rmi.RemoteException,StudentNotExistsException, CourseNotExistsException, CourseIsFullException, CourseAlreadyTakenException, TakenTooManyCourseException, PreRequisiteNotTakenException;

    public boolean unRegister(String studentID, String courseID)
            throws IOException, java.rmi.RemoteException,courseHasNotTakenException, StudentNotExistsException, CourseNotExistsException;
}
