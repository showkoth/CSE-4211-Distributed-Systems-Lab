
public class CourseAlreadyTakenException extends Exception
{
    public CourseAlreadyTakenException(String s)
    {
        super(s);
    }
}
