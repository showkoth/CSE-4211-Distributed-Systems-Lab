
public class StudentNotExistsException extends Exception
{
    public StudentNotExistsException(String s)
    {
        // Call constructor of parent Exception
        // String msg = "Student with ID " + s + " not exists!";
        super(s);
    }
}