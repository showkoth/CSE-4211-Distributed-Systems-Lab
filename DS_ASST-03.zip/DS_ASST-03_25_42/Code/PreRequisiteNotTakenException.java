
public class PreRequisiteNotTakenException extends Exception
{
    public PreRequisiteNotTakenException(String s)
    {
        super(s);
    }
}