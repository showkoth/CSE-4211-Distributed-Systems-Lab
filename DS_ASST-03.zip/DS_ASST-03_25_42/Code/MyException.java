public class MyException extends Exception{


}

