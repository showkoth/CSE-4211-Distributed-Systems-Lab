
public class NoPreRequisiteException extends Exception
{
    public NoPreRequisiteException(String s)
    {
        super(s);
    }
}
