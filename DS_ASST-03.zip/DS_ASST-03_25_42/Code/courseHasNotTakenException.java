public class courseHasNotTakenException extends Exception
{
    public courseHasNotTakenException(String s)
    {
        super(s);
    }
}