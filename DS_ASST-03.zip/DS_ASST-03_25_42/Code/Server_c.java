import java.io.*;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;


public class Server_c extends UnicastRemoteObject implements Client_i{

    public static int max_course = 3;

    public Server_c() throws RemoteException{
        super();
        //try {
        //    init_db();
        //} catch (IOException e) {
          //  e.printStackTrace();
        //}
    }

    private void init_db() throws IOException {
        fileContentUpdater("","",true, -1); // init student table
        fileContentUpdater("", "", false, -1); // init course table
    }

    @Override
    public List<String> GetRegistrationList(String studentID) throws IOException, StudentNotExistsException {
        // get all courses registered by a student
        List<String> std_info;
        if(studentID.equals("")) {
//            System.out.println("ok");
            throw new StudentNotExistsException("Exception occured: Student with ID " + studentID + " doesn't exist!") ;
        }
        else{
            std_info = getInfo( studentID, 1);
            if(std_info.size() == 0) throw new StudentNotExistsException("Exception occured: Student with ID " + studentID + " doesn't exist!") ;
            return std_info;
        }

    }

    public List<String> getInfo(String ID, int std_flag) throws IOException {
        FileReader file = null;
        try {
            if(std_flag == 1) file = new FileReader("student_list.txt");  // read the file
            else file = new FileReader("course_list.txt");  // read the file
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        BufferedReader bufRead = new BufferedReader(file); // buffered reader to iterate the file
        String myLine = null;
        List<String> li = new ArrayList<String>();
        while ((myLine = bufRead.readLine()) != null)
        {
            //String[] array1 = myLine.split(":");
//            myLine = bufRead.readLine(); // read line by line
//            System.out.println(myLine);
            String[] words;
            words = myLine.split(" ");

            if(words[0].equals(ID)){ // match with student id

//                String[] courses = words[1].split(",");
                for(int i = 0; i <words.length ; i ++){
                    li.add(words[i]); // add to list
                }
                return li; // returns the row
            }
        }
        return li;
    }

    synchronized public static void fileContentUpdater(String studentID, String courseID, boolean stdFlag, int regFlag) throws IOException { // stdFlag = 1 update student list  0 update course list
        FileReader  originalFile = null;                                                                                            // regFlag = 1 register 0 unregister -1 init
        File tempFile = new File("tempfile.txt");
        //PrintWriter pw;
        FileOutputStream fos = new FileOutputStream(tempFile);
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos)); // buffered writer to write a temp file
        try {
            if(stdFlag) originalFile = new FileReader("student_list.txt");  // read the file
            else originalFile = new FileReader("course_list.txt");
            // Construct the new file that will later be renamed to the original
            // filename

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        BufferedReader bufRead = new BufferedReader(originalFile); // buffered reader to iterate the file

        String line = null;
        // Read from the original file and write to the new
        // unless content matches data to be removed.
        while ((line = bufRead.readLine()) != null) {

            if(stdFlag){ // update the corresponding row of student list
                boolean special_flag = line.contains(studentID);
                if(regFlag == -1){
                    special_flag = true;
                }
                if (special_flag) {
                    String line_to_update = "";
                    String[] words = line.split(" ");
                    if(regFlag == 1){ // register
                        for(int i = 0; i < words.length ; i ++){
                            line_to_update = line_to_update + words[i] + " "; // row before update
                        }
                        line = line_to_update + courseID; // row after update
                    }
                    else if(regFlag == 0){ // unregister
                        for(int i = 0; i < words.length ; i ++){
                            if(words[i].equals(courseID)) continue; // skip the course to unregister
                            line_to_update = line_to_update + words[i] + " "; // row before update
                        }
                        line = line_to_update.trim(); // remove trailing spaces
                    }
                    else{ // init
                        line = words[0] ;
                    }

                }
            }

            else{ // update course list // occupied ++
                boolean special_flag = line.contains(courseID);
                if(regFlag == -1){
                    special_flag = true;
                }
                if(special_flag){ // update the corresponding row of course list
                    String line_to_update = "";
                    String[] words = line.split(" ");
                    for(int i = 0; i < words.length ; i++){
                        if(i == 2) {
                            int occupied = Integer.parseInt(words[i]);
                            if(regFlag == 1) occupied ++; // register ++
                            else if(regFlag == 0) occupied--; // unregister
                            else occupied = 0; // init
                            words[i] = String.valueOf(occupied); // row is updated
                        }
                        line_to_update = line_to_update + words[i] + " ";
                    }
                    line = line_to_update.trim(); // remove trailing space
                }
            }
            bw.write(line);

            bw.newLine(); // trailing new line exists
            bw.flush();
//            pw.println(line);
//            pw.flush();
        }
        bw.close();
        bufRead.close();
        File file;
        if(stdFlag) file = new File("student_list.txt"); // previous file to be deleted
        else file = new File("course_list.txt"); // previous file to be deleted
        // Delete the original file
        if (!file.delete()) {
            System.out.println("Could not delete file");
            return;
        }

        // Rename the new file to the filename the original file had.
        if (!tempFile.renameTo(file))
            System.out.println("Could not rename file");

    }


    boolean hasTaken(List<String> std_info, String courseID){ // check if the course is already taken by the student
        for(int i = 1; i < std_info.size(); i++){
            if(std_info.get(i).equals(courseID)) return true;
        }
        return false;
    }

    @Override
    public boolean Register(String studentID, String courseID) throws IOException, RemoteException, StudentNotExistsException, CourseNotExistsException, CourseIsFullException, CourseAlreadyTakenException, TakenTooManyCourseException, PreRequisiteNotTakenException {
        List<String> std_info = getInfo(studentID, 1);
        List<String> course_info = getInfo(courseID, 0);
//        System.out.println(std_info.size());
        if(std_info.size() == 0) throw new StudentNotExistsException("Exception occured: Student with ID " + studentID + " doesn't exist!") ;
        else if(course_info.size() == 0) throw new CourseNotExistsException("Exception occured: Course with ID " + courseID + " doesn't exist!");
        else if(course_info.get(1).equals(course_info.get(2))) throw new CourseIsFullException("Exception occured: Course " + courseID + " is full!");
        else if(hasTaken(std_info,courseID)) throw new CourseAlreadyTakenException("Exception occured: Course " + courseID + " is already taken!");
        else if(std_info.size()- 1 == max_course) throw new TakenTooManyCourseException("Exception occured: Student with ID " + studentID + " has already taken " + max_course + " courses!");
        else if(course_info.get(3).equals("None")) { // no pre-requisite

            return coRequisiteHandler(studentID, courseID, std_info, course_info);
        }

        else if(!course_info.get(3).equals("None")){ // has pre-requisite
            String pre_requisite = course_info.get(3);
            if(!hasTaken(std_info,pre_requisite)){ // has not taken the pre requisite
                throw new PreRequisiteNotTakenException("Exception occured: Course " + pre_requisite + " is a pre-requisite. Take it first.") ;
            }
            else{ // has taken the pre requisite
                return coRequisiteHandler(studentID, courseID, std_info, course_info);
            }
        }

        return false;
    }

    @Override
    public boolean unRegister(String studentID, String courseID) throws IOException, RemoteException, StudentNotExistsException, CourseNotExistsException, courseHasNotTakenException {
        List<String> std_info = getInfo(studentID, 1);
        List<String> course_info = getInfo(courseID, 0);
        if(std_info.size() == 0) throw new StudentNotExistsException("Exception occured: Student with ID " + studentID + " doesn't exist!") ;
        else if(course_info.size() == 0) throw new CourseNotExistsException("Exception occured: Course with ID " + courseID + " doesn't exist!");
        else if(!hasTaken(std_info, courseID)) throw new courseHasNotTakenException("Exception occured: Course with ID " + courseID + " has not taken yet");
        else if(course_info.get(4).equals("None")){ // has no co-requisite
            fileContentUpdater(studentID, courseID, true, 0); // update student list
            fileContentUpdater(studentID, courseID, false, 0); // update course list
            System.out.println("Unregistered Successfully");
            return true;
        }

        else{ // has co requisite
            String co_requisite = course_info.get(4);
            List<String> course_info_2 = getInfo(co_requisite, 0);
            fileContentUpdater(studentID, courseID, true, 0); // update student list
            fileContentUpdater(studentID, courseID, false, 0); // update course list
            System.out.println( courseID +" Unregistered Successfully");

            fileContentUpdater(studentID,co_requisite, true, 0); // update student list
            fileContentUpdater(studentID, co_requisite, false, 0); // update course list
            System.out.println("Co requisite course " + co_requisite +" Unregistered Successfully");

            return true;



        }
    }

    private boolean coRequisiteHandler(String studentID, String courseID, List<String> std_info, List<String> course_info) throws IOException, CourseIsFullException {
        if(course_info.get(4).equals("None")){ // has no co-requisite
            fileContentUpdater(studentID, courseID, true, 1); // update student list
            fileContentUpdater(studentID, courseID, false, 1); // update course list
            System.out.println("Registered Successfully");
            return true;
        }

        else{ // has co requisite
            String co_requisite = course_info.get(4);
            List<String> course_info_2 = getInfo(co_requisite, 0);
            if(course_info_2.get(1).equals(course_info_2.get(2))) throw new CourseIsFullException("Exception occured: Course " + courseID + " is full!");
            else if(!hasTaken(std_info,co_requisite)){ // std has not taken the co-requisite course
                if(std_info.size() - 1 < max_course - 1) { // check whether std can two course
                    fileContentUpdater(studentID, co_requisite, true, 1); // update student list
                    fileContentUpdater(studentID, co_requisite, false, 1); // update course list

                }
            }
            fileContentUpdater(studentID, courseID, true, 1); // update student list
            fileContentUpdater(studentID, courseID, false, 1); // update course list
            System.out.println("Registered Successfully");
            return true;

        }
    }
}
