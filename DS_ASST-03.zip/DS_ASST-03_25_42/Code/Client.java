import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Client {

    private static String studentID, courseID;
    private static List<String> std_info;;
    public static void main(String args[]) throws IOException, CourseIsFullException, TakenTooManyCourseException, StudentNotExistsException, CourseNotExistsException, CourseAlreadyTakenException, courseHasNotTakenException {
        try {
            Registry reg = LocateRegistry.getRegistry("192.168.0.116",5000);
            Client_i c = (Client_i) reg.lookup("C");
////            Client_i c = new Server_c();
//            Naming.lookup("rmi://localhost/add");


            System.out.println("Please enter your student ID: ");
            Scanner sc = new Scanner(System.in);
            studentID = sc.nextLine();

            System.out.println("*******************************--------****************");

            System.out.println("1. Register");
            System.out.println("2. Unregister");
            System.out.println("3. Get Registration List");
            System.out.println("4. Exit");

            while(true){
                System.out.println("Select your option: ");
                int choice = sc.nextInt();
                sc.nextLine();

                if(choice == 1){
                    System.out.println("Enter course ID to Register");
                    courseID = sc.nextLine();
//                    System.out.println(studentID + courseID);
                    try {
                        if (c.Register(studentID, courseID)) System.out.println(studentID + " successfully registers " + courseID);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    continue;
                }

                else if(choice == 2){
                    System.out.println("Enter course ID to Unregister");
                    courseID = sc.nextLine();
                    try {
                        if (c.unRegister(studentID, courseID)) System.out.println(studentID + " successfully unregisters " + courseID);
                    } catch (Exception e) {
                        System.out.println(e);

                    }
                    continue;
                }
                else if(choice == 3){
                    try {
                        std_info = c.GetRegistrationList(studentID);
                    } catch (Exception e) {
                        System.out.println(e);
                    }

                    if(std_info.size() == 1) {
                        System.out.println("You have not taken any course yet!");
                        continue;
                    }
                    System.out.println("You are currently registered to the following courses: ");
                    for(int i = 1; i < std_info.size(); i ++) {
                        System.out.println(i + ". " + std_info.get(i));
                    }
                    continue;
                }
                else if(choice == 4){
                    System.exit(0);
                }
                else{
                    System.out.println("Select the correct option!");
                    continue;
                }

            }

        }

         //If any error occur

        catch (RemoteException re) {
            System.out.println("\nRemoteException: "
                    + re);
        }

        catch (NotBoundException nbe) {
            System.out.println("\nNotBoundException: "
                    + nbe);
        }

        catch (ArithmeticException ae) {
            System.out.println("\nArithmeticException: " + ae);
        }
    }
}
