
public class CourseIsFullException extends Exception
{
    public CourseIsFullException(String s)
    {
        super(s);
    }
}