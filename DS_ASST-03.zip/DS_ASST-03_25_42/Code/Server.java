import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server {

    public Server(){
    }

    public static void main(String args[]) throws NotBoundException {
      try{
////            Server_c serve = new Server_c();
////            Client_i stub = (Client_i) UnicastRemoteObject.exportObject(serve, 0);
////            Registry registry = LocateRegistry.getRegistry();
////            registry.bind("Client_i", stub);
////            //Naming.rebind("rmi://localhost/add",c);
////            System.err.println("Server Ready");
//
        Server_c c = new Server_c();
        String ip = "192.168.0.116";
        int port = 5000;
	    System.setProperty("java.rmi.server.hostname", ip);
	    Registry reg = LocateRegistry.createRegistry(port);

//	    System.out.println("ok");
        reg.rebind("C",c);
	    System.out.println("Server Started....at " + ip + " : " + port);
        }
        catch (Exception e){
            System.out.println(e);
        }



    }

}
